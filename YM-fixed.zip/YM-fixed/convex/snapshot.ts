import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

async function requireStaff(ctx: any, email: string, pin: string) {
  const expected = process.env.ADMIN_PIN || "";
  if (!expected || pin !== expected) throw new Error("PINが違います");
  const row = await ctx.db
    .query("admin_staff")
    .withIndex("by_email", (q: any) => q.eq("email", email.trim().toLowerCase()))
    .unique();
  if (!row) throw new Error("管理者表にいません");
  return row;
}

function requireSyncToken(token: string) {
  const expected = process.env.DEV_SYNC_TOKEN || process.env.CREATOR_UNLOCK || "";
  if (!expected || token !== expected) throw new Error("同期鍵が違います");
}

export const getSnapshot = query({
  args: { email: v.string(), pin: v.string() },
  handler: async (ctx, args) => {
    await requireStaff(ctx, args.email, args.pin);
    const row = await ctx.db
      .query("dev_snapshot")
      .withIndex("by_key", (q: any) => q.eq("key", "main"))
      .unique();
    if (!row) return { payload: "{}" };
    return { payload: row.payload || "{}" };
  },
});

export const pushSnapshot = mutation({
  args: { token: v.string(), payload: v.string() },
  handler: async (ctx, args) => {
    requireSyncToken(args.token);
    const payload = String(args.payload || "").slice(0, 180000);
    const existing = await ctx.db
      .query("dev_snapshot")
      .withIndex("by_key", (q: any) => q.eq("key", "main"))
      .unique();
    if (existing) await ctx.db.patch(existing._id, { payload });
    else await ctx.db.insert("dev_snapshot", { key: "main", payload });
    return { ok: true, bytes: payload.length };
  },
});
