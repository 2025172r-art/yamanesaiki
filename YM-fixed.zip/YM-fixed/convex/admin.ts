import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

async function requireStaff(ctx: any, email: string, pin: string) {
  const expected = process.env.ADMIN_PIN || "";
  if (!expected || pin !== expected) {
    throw new Error("PINが違います");
  }
  const row = await ctx.db
    .query("admin_staff")
    .withIndex("by_email", (q: any) => q.eq("email", email.trim().toLowerCase()))
    .unique();
  if (!row) throw new Error("管理者表にいません");
  return row;
}

function requireCreator(unlock: string) {
  const expected = process.env.CREATOR_UNLOCK || "";
  if (!expected || unlock !== expected) {
    throw new Error("作成者鍵が違います");
  }
}

export const whoami = query({
  args: { email: v.string(), pin: v.string() },
  handler: async (ctx, args) => {
    const row = await requireStaff(ctx, args.email, args.pin);
    return { ok: true, email: row.email, role: row.role || "admin" };
  },
});

export const listAudit = query({
  args: { email: v.string(), pin: v.string() },
  handler: async (ctx, args) => {
    await requireStaff(ctx, args.email, args.pin);
    return await ctx.db.query("admin_audit").order("desc").take(20);
  },
});

export const listCoinLedger = query({
  args: { email: v.string(), pin: v.string() },
  handler: async (ctx, args) => {
    await requireStaff(ctx, args.email, args.pin);
    return await ctx.db.query("coin_ledger").order("desc").take(30);
  },
});

export const latestAnnouncement = query({
  args: {},
  handler: async (ctx) => {
    const rows = await ctx.db.query("admin_announcements").order("desc").take(1);
    const r = rows[0];
    if (!r) return { text: "", style: "normal", id: "" };
    return { text: r.body || "", style: r.style || "normal", id: String(r._id) };
  },
});

export const postAnnouncement = mutation({
  args: { email: v.string(), pin: v.string(), body: v.string(), style: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const staff = await requireStaff(ctx, args.email, args.pin);
    const body = args.body.trim();
    if (!body) throw new Error("本文が空です");
    await ctx.db.insert("admin_announcements", {
      body,
      style: args.style || "normal",
      actorEmail: staff.email,
    });
    await ctx.db.insert("admin_audit", {
      action: "announce",
      detail: body.slice(0, 200),
      actorEmail: staff.email,
    });
    return { ok: true };
  },
});

export const adjustCoins = mutation({
  args: {
    email: v.string(),
    pin: v.string(),
    creatorUnlock: v.string(),
    target: v.string(),
    amount: v.number(),
    note: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const staff = await requireStaff(ctx, args.email, args.pin);
    requireCreator(args.creatorUnlock);
    const target = args.target.trim();
    const amount = Math.trunc(Number(args.amount));
    if (!target) throw new Error("対象が空です");
    if (!amount) throw new Error("数量は 0 以外（例: 10 または -10）");
    if (amount > 100000 || amount < -100000) throw new Error("数量が大きすぎます");
    await ctx.db.insert("coin_ledger", {
      target,
      amount,
      note: String(args.note || "").slice(0, 200),
      actorEmail: staff.email,
    });
    await ctx.db.insert("admin_audit", {
      action: amount > 0 ? "coin_plus" : "coin_minus",
      detail: target + " " + (amount > 0 ? "+" : "") + String(amount),
      actorEmail: staff.email,
    });
    return { ok: true, target, amount };
  },
});


function requireSyncToken(token: string) {
  const expected = process.env.DEV_SYNC_TOKEN || process.env.CREATOR_UNLOCK || "";
  if (!expected || token !== expected) throw new Error("同期鍵が違います");
}

export const pushSnapshot = mutation({
  args: { token: v.string(), payload: v.string() },
  handler: async (ctx, args) => {
    requireSyncToken(args.token);
    const payload = String(args.payload || "").slice(0, 180000);
    const existing = await ctx.db
      .query("dev_snapshot")
      .withIndex("by_key", (q: any) => q.eq("key", "main"))
      .unique();
    if (existing) await ctx.db.patch(existing._id, { payload });
    else await ctx.db.insert("dev_snapshot", { key: "main", payload });
    return { ok: true, bytes: payload.length };
  },
});

export const getSnapshot = query({
  args: { email: v.string(), pin: v.string() },
  handler: async (ctx, args) => {
    await requireStaff(ctx, args.email, args.pin);
    const row = await ctx.db
      .query("dev_snapshot")
      .withIndex("by_key", (q: any) => q.eq("key", "main"))
      .unique();
    if (!row) return { payload: "{}" };
    return { payload: row.payload || "{}" };
  },
});

export const myCoinDeltas = query({
  args: { userId: v.string() },
  handler: async (ctx, args) => {
    const uid = String(args.userId || "");
    const rows = await ctx.db.query("coin_ledger").order("desc").take(80);
    return rows
      .filter((r: any) => r.target === uid || r.target === "ALL")
      .map((r: any) => ({ id: String(r._id), target: r.target, amount: r.amount }));
  },
});
