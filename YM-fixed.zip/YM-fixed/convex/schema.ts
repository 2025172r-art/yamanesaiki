import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  admin_staff: defineTable({
    email: v.string(),
    role: v.optional(v.string()),
  }).index("by_email", ["email"]),

  admin_announcements: defineTable({
    body: v.string(),
    style: v.optional(v.string()),
    actorEmail: v.string(),
  }),

  admin_audit: defineTable({
    action: v.string(),
    detail: v.string(),
    actorEmail: v.string(),
  }),

  coin_ledger: defineTable({
    target: v.string(),
    amount: v.number(),
    note: v.optional(v.string()),
    actorEmail: v.string(),
  }).index("by_target", ["target"]),

  dev_snapshot: defineTable({
    key: v.string(),
    payload: v.string(),
  }).index("by_key", ["key"]),
});
