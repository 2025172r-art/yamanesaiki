/* ===== YM World-Class AI / UX additive runtime ===== */
(function(){
    'use strict';
    const KEY={stats:'YM_AI_PERF_STATS',fast:'YM_AI_FAST_MODE'};
    function readStats(){try{const x=JSON.parse(localStorage.getItem(KEY.stats)||'{}');return {success:Number(x.success)||0,fail:Number(x.fail)||0,latencies:Array.isArray(x.latencies)?x.latencies.slice(-20):[]};}catch(e){return {success:0,fail:0,latencies:[]};}}
    function writeStats(x){try{localStorage.setItem(KEY.stats,JSON.stringify(x));}catch(e){}}
    function paintStatus(state,main,meta){const bar=document.getElementById('ym-ai-statusbar'),dot=document.getElementById('ym-ai-status-dot'),m=document.getElementById('ym-ai-status-main'),mm=document.getElementById('ym-ai-status-meta'),cancel=document.getElementById('btn-ai-cancel-generation');if(!bar||!dot||!m)return;bar.classList.add('active');dot.classList.remove('busy','error');if(state==='busy')dot.classList.add('busy');if(state==='error')dot.classList.add('error');m.textContent=main||'';if(mm)mm.textContent=meta||'';if(cancel)cancel.classList.toggle('active',state==='busy');}
    function clearStatus(){const bar=document.getElementById('ym-ai-statusbar');if(bar)bar.classList.remove('active');}
    window.ymAiPerf={
        begin(model){const started=performance.now();paintStatus('busy','AIが回答を生成しています…',model?'モデル: '+model:'');return started;},
        done(started,ok){const ms=Math.max(0,Math.round(performance.now()-started));const st=readStats();st[ok?'success':'fail']++;if(ok)st.latencies.push(ms);writeStats(st);paintStatus(ok?'ok':'error',ok?'回答を生成しました':'AI応答に失敗しました',(ms/1000).toFixed(1)+'秒');setTimeout(clearStatus,ok?2200:4200);this.paintDev();return ms;},
        paintDev(){const st=readStats(),last=st.latencies.length?st.latencies[st.latencies.length-1]:null,avg=st.latencies.length?Math.round(st.latencies.reduce((a,b)=>a+b,0)/st.latencies.length):null;const a=document.getElementById('ym-cc-ai-latency'),b=document.getElementById('ym-cc-ai-avg-latency'),c=document.getElementById('ym-cc-ai-success'),d=document.getElementById('ym-cc-ai-fail');if(a)a.textContent=last==null?'—':(last/1000).toFixed(1)+'秒';if(b)b.textContent=avg==null?'—':(avg/1000).toFixed(1)+'秒';if(c)c.textContent=String(st.success);if(d)d.textContent=String(st.fail);},
        health(){const box=document.getElementById('ym-cc-ai-health');if(!box)return;const fast=localStorage.getItem(KEY.fast)!=='off',gw=(localStorage.getItem('YM_AI_GATEWAY')||localStorage.getItem('YM_SERVER_URL')||'').trim(),checks=[{c:fast?'ok':'warn',t:fast?'高速AIモード: ON':'通常モード: 長い文脈では応答時間が増える場合があります'},{c:gw?'ok':'warn',t:gw?'AIゲートウェイ: 設定済み':'AIゲートウェイ: 未設定（公開フォールバック経路）'},{c:typeof AbortController!=='undefined'?'ok':'bad',t:typeof AbortController!=='undefined'?'キャンセル制御: 利用可能':'キャンセル制御: 非対応'},{c:typeof ReadableStream!=='undefined'?'ok':'warn',t:typeof ReadableStream!=='undefined'?'ストリーミング: 利用可能':'ストリーミング: 非対応環境'}];box.innerHTML=checks.map(x=>'<div class="ym-ai-health-item '+x.c+'">'+x.t+'</div>').join('');this.paintDev();},
        cancel(){if(typeof window.ymCancelActiveGeneration==='function')window.ymCancelActiveGeneration();}
    };
    document.addEventListener('click',function(e){if(e.target&&e.target.id==='btn-ai-cancel-generation')window.ymAiPerf.cancel();if(e.target&&e.target.id==='btn-ym-cc-ai-health'){window.ymAiPerf.health();if(typeof showToast==='function')showToast('AI接続・性能診断を更新しました');}});
    document.addEventListener('DOMContentLoaded',function(){window.ymAiPerf.paintDev();});
})();
