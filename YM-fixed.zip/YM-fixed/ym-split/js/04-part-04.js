/* ===== YM World-Class AI/UX v2 additive runtime ===== */
(function(){
    'use strict';
    const perfKey='YM_AI_PERF_STATS';
    function getPerf(){
        try{
            const x=JSON.parse(localStorage.getItem(perfKey)||'{}');
            return {success:Number(x.success)||0,fail:Number(x.fail)||0,latencies:Array.isArray(x.latencies)?x.latencies.slice(-50):[]};
        }catch(e){return {success:0,fail:0,latencies:[]};}
    }
    function paint(){
        const s=getPerf();
        const avg=s.latencies.length?Math.round(s.latencies.reduce((a,b)=>a+b,0)/s.latencies.length):0;
        const ids=[['ym-cc-ai-success',s.success],['ym-cc-ai-fail',s.fail],['ym-cc-ai-avg-latency',avg?((avg/1000).toFixed(1)+'秒'):'—']];
        ids.forEach(([id,v])=>{const el=document.getElementById(id);if(el)el.textContent=String(v);});
        const health=document.getElementById('ym-cc-ai-health');
        const qualityMode = localStorage.getItem('YM_AI_QUALITY_MODE') || 'auto';
        const qBadge = document.getElementById('ym-ai-runtime-quality');
        if (qBadge) qBadge.textContent = qualityMode === 'deep' ? '🧠 品質優先' : (qualityMode === 'fast' ? '⚡ 高速優先' : '⚖️ 自動');
        if(health && !health.dataset.ymPainted){
            health.dataset.ymPainted='1';
            const items=[
                ['ok','履歴文脈: '+(localStorage.getItem('YM_AI_CONTEXT_DEPTH')||'16')+'件'],
                [localStorage.getItem('YM_AI_AUTO_RETRY')==='off'?'warn':'ok','自動リトライ: '+(localStorage.getItem('YM_AI_AUTO_RETRY')==='off'?'OFF':'ON')],
                ['ok','AIタイムアウト: '+Math.round(Number(localStorage.getItem('YM_AI_TIMEOUT_MS')||60000)/1000)+'秒'],
                [localStorage.getItem('YM_AI_GATEWAY')||localStorage.getItem('YM_SERVER_URL')?'ok':'warn','ゲートウェイ: '+((localStorage.getItem('YM_AI_GATEWAY')||localStorage.getItem('YM_SERVER_URL'))?'設定済み':'標準フォールバック')],
                ['ok','認証情報: 一時メモリ利用（平文パスワード保存を廃止）']
            ];
            health.innerHTML=items.map(x=>'<div class="ym-ai-health-item '+x[0]+'">'+x[1]+'</div>').join('');
        }
    }
    window.YMWorldClassAI={refresh:paint,setTimeoutMs:function(ms){ms=Math.min(120000,Math.max(30000,Number(ms)||60000));localStorage.setItem('YM_AI_TIMEOUT_MS',String(ms));paint();}};
    document.addEventListener('DOMContentLoaded',paint);
})();
