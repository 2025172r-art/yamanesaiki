/* ===== YM v14 additive runtime ===== */
(function(){
    'use strict';
    const state = window.YMWorldClassV14 = {
        transferRecoveries: 0,
        memoryEnabled: false,
        lastInputAt: 0,
        update(){
            this.memoryEnabled = localStorage.getItem('YM_AI_MEMORY_ENABLED') === 'on';
            const badge = document.getElementById('ym-ai-runtime-quality');
            if (badge && this.memoryEnabled) badge.title = '明示的に保存したAI会話メモリを使用中';
        },
        openSearch(){
            const el = document.getElementById('ym-cc-global-search') || document.getElementById('chat-search-input');
            if (el){ el.focus(); el.select?.(); }
        },
        metrics(){
            return { transferRecoveries:this.transferRecoveries, memoryEnabled:this.memoryEnabled, lastInputAt:this.lastInputAt };
        }
    };
    try { state.update(); } catch(e) {}

    document.addEventListener('keydown', function(e){
        if (e.defaultPrevented) return;
        const tag = String(e.target?.tagName || '').toLowerCase();
        const typing = tag === 'input' || tag === 'textarea' || tag === 'select' || e.target?.isContentEditable;
        if (e.key === 'k' && (e.ctrlKey || e.metaKey) && !typing){
            e.preventDefault();
            state.openSearch();
            return;
        }
        if (e.key === 'Escape'){
            document.querySelectorAll('.ctx-menu.active,.header-overflow-menu.active,.bottom-sheet.active').forEach(el=>el.classList.remove('active'));
        }
    }, {capture:true});

    document.addEventListener('input', function(e){
        state.lastInputAt = Date.now();
    }, {passive:true});

    const mem = document.getElementById('ai-chat-settings-memory-enabled');
    if (mem) mem.addEventListener('change', function(){ state.update(); });
    const memArea = document.getElementById('ai-chat-settings-memory');
    if (memArea) memArea.addEventListener('input', function(){ state.update(); }, {passive:true});

    window.addEventListener('beforeunload', function(){
        try { localStorage.removeItem('YM_AI_MEMORY_DRAFT'); } catch(e) {}
    });

    state.update();
})();
