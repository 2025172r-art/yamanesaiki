/* ===== YM World-Class v15 runtime: smart pagination + AI memory tools ===== */
(function(){
    'use strict';
    const V15 = window.YMWorldClassV15 = {
        autoLoads: 0,
        memoryExports: 0,
        memoryImports: 0,
        lastLoadAt: 0
    };

    function getChatContainer(){ return document.getElementById('chat-messages'); }
    function getOlderButton(){
        const c = getChatContainer();
        if (!c) return null;
        return Array.from(c.querySelectorAll('.load-older-btn')).find(b => /^↑/.test(String(b.textContent || '').trim())) || null;
    }

    let loadingOlder = false;
    async function maybeLoadOlder(){
        const c = getChatContainer();
        const b = getOlderButton();
        if (!c || !b || loadingOlder) return;
        if (c.scrollTop > 48) return;
        const now = Date.now();
        if (now - V15.lastLoadAt < 350) return;
        loadingOlder = true;
        V15.lastLoadAt = now;
        const beforeHeight = c.scrollHeight;
        const beforeTop = c.scrollTop;
        const badge = document.getElementById('ym-v15-load-state');
        if (badge) badge.classList.add('active');
        try{
            V15.autoLoads++;
            b.click();
            await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
            const delta = c.scrollHeight - beforeHeight;
            c.scrollTop = Math.max(0, beforeTop + delta);
        }catch(e){}
        finally{
            loadingOlder = false;
            if (badge) badge.classList.remove('active');
        }
    }

    function bindChatScroll(){
        const c = getChatContainer();
        if (!c || c.dataset.ymV15Bound === '1') return;
        c.dataset.ymV15Bound = '1';
        let raf = 0;
        c.addEventListener('scroll', function(){
            if (raf) return;
            raf = requestAnimationFrame(() => { raf = 0; maybeLoadOlder(); });
        }, {passive:true});
    }

    function ensureLoadBadge(){
        const c = getChatContainer();
        if (!c || document.getElementById('ym-v15-load-state')) return;
        const el = document.createElement('div');
        el.id = 'ym-v15-load-state';
        el.className = 'ym-v15-load-state';
        el.textContent = '過去のメッセージを読み込み中…';
        c.parentElement?.appendChild(el);
    }

    function downloadJson(filename, data){
        try{
            const blob = new Blob([JSON.stringify(data,null,2)], {type:'application/json'});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = filename;
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
            return true;
        }catch(e){ return false; }
    }

    function refreshMemoryStatus(){
        const el = document.getElementById('ym-v15-memory-status');
        if (!el) return;
        const enabled = localStorage.getItem('YM_AI_MEMORY_ENABLED') === 'on';
        const mem = String(localStorage.getItem('YM_AI_MEMORY') || '').trim();
        el.textContent = enabled ? ('保存メモリ: ON ・ ' + mem.length + '文字') : '保存メモリ: OFF';
    }

    function installMemoryTools(){
        const area = document.getElementById('ai-chat-settings-memory');
        if (!area || document.getElementById('ym-v15-memory-tools')) return;
        const wrap = document.createElement('div');
        wrap.id = 'ym-v15-memory-tools';
        wrap.className = 'ym-v15-tools';
        wrap.innerHTML =
            '<button type="button" class="menu-btn" id="btn-v15-memory-export">メモリを書き出す</button>' +
            '<button type="button" class="menu-btn" id="btn-v15-memory-import">メモリを読み込む</button>' +
            '<button type="button" class="menu-btn btn-danger" id="btn-v15-memory-clear">メモリを消去</button>' +
            '<div class="ym-v15-memory-status" id="ym-v15-memory-status"></div>' +
            '<input id="v15-memory-file" type="file" accept="application/json,.json" hidden>';
        area.insertAdjacentElement('afterend', wrap);
        refreshMemoryStatus();

        document.getElementById('btn-v15-memory-export')?.addEventListener('click', function(){
            const data = {
                version: 1,
                exportedAt: new Date().toISOString(),
                enabled: localStorage.getItem('YM_AI_MEMORY_ENABLED') === 'on',
                memory: String(localStorage.getItem('YM_AI_MEMORY') || '').slice(0,4000)
            };
            if (downloadJson('ym-ai-memory.json', data)) {
                V15.memoryExports++;
                if (typeof showToast === 'function') showToast('AIメモリを書き出しました。');
            }
        });

        document.getElementById('btn-v15-memory-import')?.addEventListener('click', function(){
            document.getElementById('v15-memory-file')?.click();
        });
        document.getElementById('v15-memory-file')?.addEventListener('change', async function(e){
            const file = e.target.files && e.target.files[0];
            if (!file) return;
            try{
                const raw = await file.text();
                const data = JSON.parse(raw);
                const mem = String(data.memory || '').trim().slice(0,4000);
                localStorage.setItem('YM_AI_MEMORY', mem);
                localStorage.setItem('YM_AI_MEMORY_ENABLED', data.enabled ? 'on' : 'off');
                V15.memoryImports++;
                const memArea = document.getElementById('ai-chat-settings-memory');
                const memEnabled = document.getElementById('ai-chat-settings-memory-enabled');
                if (memArea) memArea.value = mem;
                if (memEnabled) memEnabled.checked = data.enabled === true;
                refreshMemoryStatus();
                if (typeof showToast === 'function') showToast('AIメモリを読み込みました。');
            }catch(err){
                if (typeof showToast === 'function') showToast('AIメモリの読み込みに失敗しました。');
            }finally{
                e.target.value = '';
            }
        });
        document.getElementById('btn-v15-memory-clear')?.addEventListener('click', function(){
            if (!confirm('保存済みAIメモリを消去しますか？')) return;
            localStorage.removeItem('YM_AI_MEMORY');
            localStorage.setItem('YM_AI_MEMORY_ENABLED','off');
            const memArea = document.getElementById('ai-chat-settings-memory');
            const memEnabled = document.getElementById('ai-chat-settings-memory-enabled');
            if (memArea) memArea.value = '';
            if (memEnabled) memEnabled.checked = false;
            refreshMemoryStatus();
            if (typeof showToast === 'function') showToast('AIメモリを消去しました。');
        });
    }

    document.addEventListener('DOMContentLoaded', function(){
        bindChatScroll();
        ensureLoadBadge();
        installMemoryTools();
        refreshMemoryStatus();
    });

    const installer = setInterval(function(){
        bindChatScroll();
        ensureLoadBadge();
        installMemoryTools();
        refreshMemoryStatus();
    }, 1500);
    setTimeout(() => clearInterval(installer), 20000);

    window.addEventListener('beforeunload', () => clearInterval(installer));
})();
