        /* ===== YM 公式LP / ルーティング追加 ===== */
        (function () {
            'use strict';
            function lp(){ return document.getElementById('ym-official-lp'); }
            function visible(v){ const e=lp(); if(e)e.classList.toggle('hidden',!v); }
            function goChat(){
                try { const target=(typeof activeChatTarget!=='undefined')?activeChatTarget:null; if(typeof switchPage==='function') switchPage(target?'chat-view':'home-view'); } catch(e){}
                visible(false);
                try { history.pushState({ymLp:false,ymChat:true},'', '#chat-messages'); } catch(e) { location.hash='#chat-messages'; }
            }
            function isChat(){ return location.pathname==='/chat'||location.hash==='#chat-messages'||location.hash==='#chat'; }
            function isRoot(){ return (location.pathname==='/'||location.pathname==='')&&!location.hash; }
            function route(){
                if(isChat()){ visible(false); try { if(typeof switchPage==='function'){ const target=(typeof activeChatTarget!=='undefined')?activeChatTarget:null; switchPage(target?'chat-view':'home-view'); } } catch(e){} return; }
                if(isRoot()){ visible(true); return; }
                visible(false);
            }
            function openAuth(mode){
                const m=document.getElementById('ym-lp-auth-modal'), t=document.getElementById('ym-lp-auth-title'), d=document.getElementById('ym-lp-auth-description'), b=document.getElementById('ym-lp-auth-submit'), st=document.getElementById('ym-lp-auth-status');
                if(!m)return; const signup=mode==='signup'; m.dataset.mode=signup?'signup':'login'; if(t)t.textContent=signup?'YMに新規登録':'YMにログイン'; if(d)d.textContent=signup?'Supabase認証でYMアカウントを作成します。登録後はそのままチャットへ進めます。':'Supabase認証を利用してYMにログインします。'; if(b)b.textContent=signup?'新規登録':'ログイン'; if(st)st.textContent=''; m.classList.remove('hidden'); setTimeout(()=>document.getElementById('ym-lp-auth-email')?.focus(),0);
            }
            function closeAuth(){ document.getElementById('ym-lp-auth-modal')?.classList.add('hidden'); }
            async function submitAuth(){
                const m=document.getElementById('ym-lp-auth-modal'), em=String(document.getElementById('ym-lp-auth-email')?.value||'').trim(), pw=String(document.getElementById('ym-lp-auth-password')?.value||''), st=document.getElementById('ym-lp-auth-status'), b=document.getElementById('ym-lp-auth-submit'), mode=m?.dataset.mode||'login';
                if(!em||!pw){if(st)st.textContent='メールアドレスとパスワードを入力してください。';return;} if(b)b.disabled=true; if(st)st.textContent='処理しています…';
                try {
                    if(typeof YMSupabase==='undefined')throw new Error('認証機能を初期化できませんでした。'); if(!YMSupabase.client)await YMSupabase.init(); if(!YMSupabase.client)throw new Error('Supabaseに接続できません。');
                    let r; if(mode==='signup'){ r=await YMSupabase.client.auth.signUp({email:em,password:pw}); if(r.error)throw r.error; if(r.data?.session){YMSupabase.user=r.data.user;YMSupabase.ready=true;closeAuth();goChat();}else if(st)st.textContent='登録を受け付けました。メール確認が必要な場合は確認後にログインしてください。'; }
                    else { r=await YMSupabase.client.auth.signInWithPassword({email:em,password:pw}); if(r.error)throw r.error; YMSupabase.user=r.data.user;YMSupabase.ready=true; localStorage.setItem('YM_SUPABASE_EMAIL',em); YMSupabase._pendingPassword = ''; closeAuth(); goChat(); }
                } catch(e){if(st)st.textContent=String(e?.message||'認証に失敗しました。');} finally {if(b)b.disabled=false;}
            }
            function bind(){
                ['ym-lp-chat-btn','ym-lp-cta-chat'].forEach(id=>document.getElementById(id)?.addEventListener('click',goChat));
                ['ym-lp-login-top','ym-lp-login-hero'].forEach(id=>document.getElementById(id)?.addEventListener('click',()=>openAuth('login')));
                ['ym-lp-signup-top','ym-lp-signup-hero'].forEach(id=>document.getElementById(id)?.addEventListener('click',()=>openAuth('signup')));
                document.getElementById('ym-lp-auth-cancel')?.addEventListener('click',closeAuth); document.getElementById('ym-lp-auth-submit')?.addEventListener('click',submitAuth);
                document.getElementById('ym-lp-auth-modal')?.addEventListener('click',e=>{if(e.target.id==='ym-lp-auth-modal')closeAuth();}); document.getElementById('ym-lp-auth-password')?.addEventListener('keydown',e=>{if(e.key==='Enter')submitAuth();});
                window.addEventListener('popstate',route); window.addEventListener('hashchange',route); route(); setTimeout(route,0); setTimeout(route,600);
            }
            document.addEventListener('DOMContentLoaded',bind);
        })();
    
