/* ===== YM World-Class v13 runtime: runtime health + safe performance hardening ===== */
(function(){
  'use strict';
  const KEY='YM_V13_RUNTIME_METRICS';
  const metrics={longTasks:0,domMutations:0,imagesOptimized:0,renderSkipHits:0,started:Date.now()};
  const optimizedImages=new WeakSet();
  let rafSave=0;

  function safe(fn){try{return fn()}catch(e){return undefined}}
  function save(){try{sessionStorage.setItem(KEY,JSON.stringify(metrics))}catch(e){}}
  function scheduleSave(){
    if(rafSave)return;
    rafSave=1;
    const cb=window.requestIdleCallback||function(f){setTimeout(f,300)};
    cb(function(){rafSave=0;save()},{timeout:1200});
  }
  function optimizeNode(root){
    if(!root || document.visibilityState==='hidden') return;
    try{
      const imgs=[];
      if(root.nodeType===1 && root.tagName==='IMG') imgs.push(root);
      if(root.querySelectorAll) root.querySelectorAll('img').forEach(img=>imgs.push(img));
      imgs.forEach(img=>{
        if(optimizedImages.has(img)) return;
        optimizedImages.add(img);
        if(!img.hasAttribute('loading')) img.loading='lazy';
        if(!img.hasAttribute('decoding')) img.decoding='async';
        if(!img.hasAttribute('fetchpriority')) img.fetchPriority='low';
        metrics.imagesOptimized++;
      });
      if(root.nodeType===1 && root.matches && root.matches('.msg-wrapper')){
        root.style.contentVisibility='auto';
        root.style.containIntrinsicSize='96px';
      }
      if(root.querySelectorAll) root.querySelectorAll('.msg-wrapper').forEach(el=>{
        el.style.contentVisibility='auto';
        el.style.containIntrinsicSize='96px';
      });
    }catch(e){}
  }
  async function persistStorage(){
    try{
      if(navigator.storage && navigator.storage.persist){
        const already=await navigator.storage.persisted();
        if(!already) await navigator.storage.persist();
      }
    }catch(e){}
  }
  function updateUI(){
    const set=(id,v)=>{const el=document.getElementById(id);if(el)el.textContent=String(v)};
    set('ym-v13-longtasks',metrics.longTasks);
    set('ym-v13-mutations',metrics.domMutations);
    set('ym-v13-images',metrics.imagesOptimized);
    set('ym-v13-renderskip',metrics.renderSkipHits);
    if(navigator.storage && navigator.storage.estimate){
      navigator.storage.estimate().then(x=>{
        const u=Number(x.usage||0), q=Number(x.quota||0);
        set('ym-v13-storage',q?((u/1048576).toFixed(1)+' / '+(q/1048576).toFixed(0)+' MB'):(u?((u/1048576).toFixed(1)+' MB'):'—'));
      }).catch(()=>{});
    }
    const conn=navigator.connection||navigator.mozConnection||navigator.webkitConnection;
    set('ym-v13-network',conn?(String(conn.effectiveType||'unknown')+(conn.saveData?' / Save-Data':'')):(navigator.onLine?'online':'offline'));
    const note=document.getElementById('ym-v13-runtime-note');
    if(note){
      const mem=safe(()=>performance.memory);
      note.textContent=(mem?'JS heap '+(mem.usedJSHeapSize/1048576).toFixed(1)+'MB / '+(mem.jsHeapSizeLimit/1048576).toFixed(0)+'MB ・ ':'')+
        (navigator.onLine?'Network online':'Network offline')+' ・ 長時間処理 '+metrics.longTasks+'件';
    }
  }
  function installObserver(){
    if(typeof MutationObserver!=='undefined'){
      const mo=new MutationObserver(list=>{
        metrics.domMutations+=list.length;
        list.forEach(r=>{
          if(!r.addedNodes||!r.addedNodes.length)return;
          r.addedNodes.forEach(node=>{if(node&&(node.nodeType===1||node.nodeType===11))optimizeNode(node)});
        });
        scheduleSave();
      });
      mo.observe(document.body,{childList:true,subtree:true});
    }
    if(typeof PerformanceObserver!=='undefined'){
      try{
        const po=new PerformanceObserver(list=>{
          metrics.longTasks+=list.getEntries().length;
          scheduleSave();
          updateUI();
        });
        po.observe({type:'longtask',buffered:true});
      }catch(e){}
    }
    optimizeNode(document);
    updateUI();
    save();
  }
  function installErrorBridge(){
    window.addEventListener('error',e=>{
      try{
        if(typeof YMControlCenter!=='undefined'&&typeof YMControlCenter.log==='function'){
          YMControlCenter.log('RUNTIME_ERROR',String(e.message||'window error')+' @ '+String(e.filename||'').slice(-120)+':'+String(e.lineno||0),'error');
        }
      }catch(_){}
    });
    window.addEventListener('unhandledrejection',e=>{
      try{
        const reason=e&&e.reason;
        if(reason&&reason.name==='AbortError')return;
        if(typeof YMControlCenter!=='undefined'&&typeof YMControlCenter.log==='function'){
          YMControlCenter.log('UNHANDLED_REJECTION',String(reason&&reason.message||reason||'Promise rejection').slice(0,600),'error');
        }
      }catch(_){}
    });
  }
  function installNetworkSignals(){
    window.addEventListener('online',updateUI,{passive:true});
    window.addEventListener('offline',updateUI,{passive:true});
    const conn=navigator.connection||navigator.mozConnection||navigator.webkitConnection;
    if(conn&&conn.addEventListener)conn.addEventListener('change',updateUI,{passive:true});
  }
  window.YMWorldClassV13={
    metrics:()=>({...metrics}),
    bumpRenderSkip:()=>{metrics.renderSkipHits++;scheduleSave();},
    refresh:()=>{optimizeNode(document);updateUI();save();return {...metrics}},
    storage:persistStorage
  };
  document.addEventListener('DOMContentLoaded',()=>{
    installObserver();
    installErrorBridge();
    installNetworkSignals();
    persistStorage();
    setInterval(updateUI,15000);
  });
})();
