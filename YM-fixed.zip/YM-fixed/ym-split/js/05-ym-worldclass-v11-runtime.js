/* ===== YM World-Class v12 runtime: targeted media optimization + keyboard UX ===== */
(function(){
'use strict';
const KEY='YM_V11_RUNTIME_METRICS';
const metrics={longTasks:0,domMutations:0,imagesOptimized:0,started:Date.now()};
const optimizedImages=new WeakSet();
function save(){try{sessionStorage.setItem(KEY,JSON.stringify(metrics));}catch(e){}}
function optimize(root){
  try{
    if(!root) return;
    const list=[];
    if(root.nodeType===1 && root.tagName==='IMG') list.push(root);
    if(root.querySelectorAll) root.querySelectorAll('img').forEach(img=>list.push(img));
    list.forEach(img=>{
      if(optimizedImages.has(img)) return;
      optimizedImages.add(img);
      if(!img.hasAttribute('loading')) img.loading='lazy';
      if(!img.hasAttribute('decoding')) img.decoding='async';
      if(!img.hasAttribute('fetchpriority')) img.fetchPriority='low';
      metrics.imagesOptimized++;
    });
    if(root.nodeType===1 && root.matches && root.matches('.msg-wrapper')) root.style.contentVisibility='auto';
    if(root.querySelectorAll) root.querySelectorAll('.msg-wrapper').forEach(el=>{el.style.contentVisibility='auto';el.style.containIntrinsicSize='96px';});
  }catch(e){}
}
function installObserver(){
  if(typeof MutationObserver!=='undefined'){
    const mo=new MutationObserver(list=>{
      metrics.domMutations+=list.length;
      let rafQueued=false;
      list.forEach(record=>{
        if(!record.addedNodes || !record.addedNodes.length) return;
        if(!rafQueued){rafQueued=true;requestAnimationFrame(()=>{rafQueued=false;save();});}
        record.addedNodes.forEach(node=>{ if(node && (node.nodeType===1 || node.nodeType===11)) optimize(node); });
      });
      if(metrics.domMutations%8===0)save();
    });
    mo.observe(document.body,{childList:true,subtree:true});
  }
  if(typeof PerformanceObserver!=='undefined'){
    try{const po=new PerformanceObserver(list=>{metrics.longTasks+=list.getEntries().length;save();});po.observe({type:'longtask',buffered:true});}catch(e){}
  }
  optimize(document); save();
}
function focusGlobalSearch(){
  const el=document.getElementById('ym-cc-global-search')||document.getElementById('chat-search-input')||document.getElementById('talk-user-search-input');
  if(el){el.focus();el.select?.();return true} return false;
}
function focusChatSearch(){
  const el=document.getElementById('chat-search-input');
  if(el){el.focus();el.select?.();return true} return false;
}
function closeTransientMenus(){
  document.querySelectorAll('.ctx-menu.active,.msg-action-menu:not(.hidden),.header-overflow-menu.active').forEach(el=>{el.classList.remove('active','open-up','open-left','open-right');if(el.classList.contains('msg-action-menu'))el.classList.add('hidden');});
  document.querySelectorAll('.reaction-popover').forEach(el=>el.remove());
}
function bindKeys(){
 document.addEventListener('keydown',e=>{
   const tag=String(e.target?.tagName||'').toLowerCase();
   const typing=tag==='input'||tag==='textarea'||e.target?.isContentEditable;
   if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();focusGlobalSearch();return;}
   if((e.ctrlKey||e.metaKey)&&e.shiftKey&&e.key.toLowerCase()==='f'){e.preventDefault();focusChatSearch();return;}
   if(e.key==='Escape'&&!typing){closeTransientMenus();}
   if(!typing&&e.key==='/'){if(focusGlobalSearch())e.preventDefault();}
 });
}
window.YMWorldClassV11={
 refresh(){optimize(document);save();return {...metrics};},
 metrics(){return {...metrics}},
 search(){return focusGlobalSearch()},
 chatSearch(){return focusChatSearch()}
};
document.addEventListener('DOMContentLoaded',()=>{installObserver();bindKeys();});
})();
